package uz.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListener : NotificationListenerService() {

    companion object {
        private val messages = ArrayList<String>()

        fun takeAll(): List<String> = synchronized(messages) {
            val copy = ArrayList(messages)
            messages.clear()
            copy
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.isBlank()) return

        val app = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        val line = "$app, $title: $text"
        synchronized(messages) {
            if (messages.isNotEmpty() && messages[messages.size - 1] == line) return
            messages.add(line)
            while (messages.size > 20) messages.removeAt(0)
        }
    }
}
